package com.example.mapper;

import com.example.model.UserModel;

public interface UserMapper {

	Object insert(UserModel userModel);

}
