package com.example.service;

import com.example.model.UserModel;

public interface UserService {
	public Object insert(UserModel userModel);
}
